package Machaty_Matyas_FB4B8Z_4;

public class jatek {
    private String Name;
    private String Game;

    public jatek(String name, String game) {
        Name = name;
        Game = game;
    }

    public String getName() {
        return Name;
    }

    public String getGame() {
        return Game;
    }
}
