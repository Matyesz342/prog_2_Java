package Machaty_Matyas_FB4B8Z_1_2_3;

public class HianyosSorException extends RuntimeException{
    public HianyosSorException()
    {
        super("Hiányzó hallgatói adat!");
    }
}
